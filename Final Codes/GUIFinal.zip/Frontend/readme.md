Frontend Directory

File Descriptions:
This directory contains the front end codes 

To start the front end:
1. ensure you have node and node package manager installed, 
if not, install your required node version from https://nodejs.org/en/
2. Install required node dependencies with the command:
$npm install
3. Start the front end with the command:
$npm start