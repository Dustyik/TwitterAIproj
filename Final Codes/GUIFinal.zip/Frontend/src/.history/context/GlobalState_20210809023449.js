import React, { createContext, useReducer } from "react";
import AppReducer from './AppReducer.js';

//tweets will be mapped to this dataset

function mse(a, b) {
	let error = 0
	for (let i = 0; i < a.length; i++) {
		error += Math.pow((b[i] - a[i]), 2)
	}
	return error / a.length
}

const initialState = {
    currentTweet:null,
    title:"nill",
    searchModels: "", 
    retweetGuessArray:[],
    humanPredictionDifference:[],
    modelPredictionDifference:[],
    guess:null,
    tweets: [
        {
            id: 1,
            user: {
                name: 'The White House',
                image: 'https://pbs.twimg.com/profile_images/1059888693945630720/yex0Gcbi_bigger.jpg',
                handle: '@WhiteHouse',
            },
            tweet: {
                content: 'On World Health Day, 2020, "we reaffirm our commitment to do our part to stop the spread of this virus, care for the sick, and protect the health and well-being of our fellow Americans."',
                image: 'https://pbs.twimg.com/card_img/1246823270524973058/IbkZhS3u?format=jpg&name=small',
                comments: '100',
                retweets: '320',
                likes: '1k',
                relevance: "nil"
            }
        },
        {
            id: 2,
            user: {
                name: 'Barack Obama',
                image: 'https://pbs.twimg.com/profile_images/822547732376207360/5g0FC8XX_bigger.jpg',
                handle: '@BarackObama',
            },
            tweet: {
                content: `My advisor and friend @cecmunoz has been someone I’ve turned to for years. In her new book, More Than Ready, she shares her story and an empowering message to women, especially women of color, that they are the leaders we need to make a change in our world.`,
                image: 'https://pbs.twimg.com/media/EVBZFzbXkAA95FX?format=jpg&name=small',
                comments: '2k',
                retweets: '5k',
                likes: '10k',
                relevance: "nil"
            }
        },
        {
            id: 3,
            user: {
                name: 'CNN',
                image: 'https://pbs.twimg.com/profile_images/508960761826131968/LnvhR8ED_bigger.png',
                handle: '@CNN',
            },
            tweet: {
                content: 'A massive plan by the federal government to buy 600 million N95 face masks may not even help fight the coronavirus pandemic at its peak because the federal government had such a low supply of masks heading into the crisis.',
                image: 'https://pbs.twimg.com/card_img/1247587714628603904/gzqe3c-i?format=jpg&name=small',
                time: '1h',
                comments: '1.3k',
                retweets: '3.4k',
                likes: '10k',
                relevance: "nil"
            }
        }
    ],
    winModalOpen:false,
    loseModalOpen:false

}

// create context
export const GlobalContext = createContext(initialState);

// provider
export const GlobalProvider = ({ children }) => {
    const [state, dispatch] = useReducer(AppReducer, initialState);

    function addHumanPredictionDifference(amount){
        dispatch({
            type: "ADD_HUMAN_PREDICITON_DIFFERENCE",
            payload:amount
        })
    }

    function setGuess(payload){
        dispatch({
            type: "SET_GUESS",
            payload:payload
        })
    }

    function removeTweet(tweetKey){
        dispatch({
            type:"REMOVE_TWEET",
            payload: tweetKey
        })
    }
    

    function setCurrentTweet(tweet){
        dispatch({
            type: "SET_CURRENT_TWEET",
            payload:tweet
        })
    }


    function addModelPredictionDifference(amount){
        dispatch({
            type: "ADD_MODEL_PREDICITON_DIFFERENCE",
            payload:amount
        })
    }

    function setSearchModels(model){
        dispatch({
            type: "SET_SEARCH_MODEL",
            payload:model
        })
    }

    function getTweet(id) {
        return state.tweets.find(tweet => tweet.id == id);
    }

    function setTweets(tweets_array) {
        dispatch({
            type: "SET_TWEETS",
            payload: tweets_array
        })
    }

    function addTweet(tweets) {
        dispatch({
            type: 'ADD_TWEET',
            payload: tweets
        })
    }

    function removeAllTweets(){
        dispatch({
            type:"REMOVE_ALL_TWEETS"
        })
    }


    function toggleWinModal(){
        dispatch({
            type: "TOGGLE_WIN_MODAL",
            payload: !state.winModalOpen
        })
    }

    function toggleLoseModal(){
        dispatch({
            type: "TOGGLE_LOSE_MODAL",
            payload: !state.loseModalOpen
        })
    }

    return (
    <GlobalContext.Provider 
        value={{ tweets: state.tweets, 
                retweetGuessArray: state.retweetGuessArray,
                setTweets, 
                getTweet, 
                addTweet,
                title:state.title, 
                setSearchModels,
                removeAllTweets,
                winModalOpen:state.winModalOpen,
                loseModalOpen:state.loseModalOpen,
                removeTweet,
                toggleWinModal,
                toggleLoseModal,
                addHumanPredictionDifference,
                addModelPredictionDifference,
                setGuess,
                guess:state.guess,
                humanPredictionDifference:state.humanPredictionDifference,
                modelPredictionDifference:state.modelPredictionDifference,
                searchModels:state.searchModels,
                setCurrentTweet,
                currentTweet: state.currentTweet
                }}>
        {children}
    </GlobalContext.Provider>)
}
